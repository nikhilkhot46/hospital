<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->model(array(
			'patient_model',
			'doctor_model',
            'document_model' 
		));

		if ($this->session->userdata('isLogIn') == false
			|| $this->session->userdata('user_role') != 1) 
			redirect('login');
	}
 
	public function index()
	{ 
		$data['title'] = display('patient_list');
		$data['patients'] = $this->patient_model->read();
		$data['content'] = $this->load->view('patient',$data,true);
		$this->load->view('layout/main_wrapper',$data);
	} 

    public function email_check($email, $id)
    { 
        $emailExists = $this->db->select('email')
            ->where('email',$email) 
            ->where_not_in('id',$id) 
            ->get('patient')
            ->num_rows();

        if ($emailExists > 0) {
            $this->form_validation->set_message('email_check', 'The {field} field must contain a unique value.');
            return false;
        } else {
            return true;
        }
    }

	public function create()
	{
		$data['title'] = display('add_patient');
        $id = $this->input->post('id');
		#-------------------------------#
		$this->form_validation->set_rules('firstname', display('first_name'),'required|max_length[50]');
		$this->form_validation->set_rules('lastname', display('last_name'),'required|max_length[50]');
		if ($this->input->post('id') == null) {
			$this->form_validation->set_rules('email', display('email'),'required|max_length[100]|is_unique[patient.email]|valid_email');
		} else {        
			$this->form_validation->set_rules('email',display('email'), "required|max_length[50]|valid_email|callback_email_check[$id]");
		}

		$this->form_validation->set_rules('password', display('password'),'required|max_length[32]');
		$this->form_validation->set_rules('phone', display('phone'),'max_length[20]');
		$this->form_validation->set_rules('mobile', display('mobile'),'required|regex_match[/^[0-9]{10}$/]');
		$this->form_validation->set_rules('blood_group', display('blood_group'),'max_length[10]');
		$this->form_validation->set_rules('sex', display('sex'),'required|max_length[10]');
		$this->form_validation->set_rules('date_of_birth', display('date_of_birth'),'required|max_length[10]');
		$this->form_validation->set_rules('address', display('address'),'required|max_length[255]');
		$this->form_validation->set_rules('status', display('status'),'required');
		#-------------------------------#
		//picture upload
		$picture = $this->fileupload->do_upload(
			'assets/images/patient/',
			'picture'
		);
		// if picture is uploaded then resize the picture
		if ($picture !== false && $picture != null) {
			$this->fileupload->do_resize( 
				$picture, 293, 350
			);
		}
		//if picture is not uploaded
		if ($picture === false) {
			$this->session->set_flashdata('exception', display('invalid_picture'));
		}
		#-------------------------------#
		if ($this->input->post('id') == null) { //create a patient
			$data['patient'] = (object)$postData = [
				'id'   		   => $this->input->post('id'),
				'patient_id'   => "P".$this->randStrGen(2,7),
				'firstname'    => $this->input->post('firstname'),
				'lastname' 	   => $this->input->post('lastname'),
				'email' 	   => $this->input->post('email'),
				'password' 	   => md5($this->input->post('password')),
				'phone'   	   => $this->input->post('phone'),
				'mobile'       => $this->input->post('mobile'),
				'blood_group'  => $this->input->post('blood_group'),
				'sex' 		   => $this->input->post('sex'), 
				'date_of_birth' => date('Y-m-d', strtotime(($this->input->post('date_of_birth') != null)? $this->input->post('date_of_birth'): date('Y-m-d'))),
				'address' 	   => $this->input->post('address'),
				'picture'      => (!empty($picture)?$picture:$this->input->post('old_picture')),
				'affliate'     => null,
				'create_date'  => date('Y-m-d'),
				'created_by'   => $this->session->userdata('user_id'),
				'status'       => $this->input->post('status'),
			]; 
		} else { // update patient
			$data['patient'] = (object)$postData = [
				'id'   		   => $this->input->post('id'),
				'firstname'    => $this->input->post('firstname'),
				'lastname' 	   => $this->input->post('lastname'),
				'email' 	   => $this->input->post('email'),
				'password' 	   => md5($this->input->post('password')),
				'phone'   	   => $this->input->post('phone'),
				'mobile'       => $this->input->post('mobile'),
				'blood_group'  => $this->input->post('blood_group'),
				'sex' 		   => $this->input->post('sex'),
				'date_of_birth' => date('Y-m-d', strtotime($this->input->post('date_of_birth'))),
				'address' 	   => $this->input->post('address'),
				'picture'      => (!empty($picture)?$picture:$this->input->post('old_picture')),
				'affliate'     => null, 
				'created_by'   => $this->session->userdata('user_id'),
				'status'       => $this->input->post('status'),
			]; 
		}
		#-------------------------------#
		if ($this->form_validation->run() === true) {

			#if empty $id then insert data
			if (empty($postData['id'])) {
				if ($this->patient_model->create($postData)) {
					$patient_id = $this->db->insert_id();
					$this->db->select('*');
					$this->db->from('patient');
					$query = $this->db->get();
					foreach ($query->result() as $row) {
						$json_customer[] = array('label'=>"($row->patient_id) - ".$row->firstname." ".$row->lastname,'value'=>$row->patient_id);
					}
					$cache_file ='./my-assets/js/admin_js/json/customer.json';
					$customerList = json_encode($json_customer);
					file_put_contents($cache_file,$customerList);
					
					#-------------------------------------------------------#
	            #-------------------------SMS SEND -----------------------------#
	                #-------------------------------------------------------#
	                # SMS Setting
	                $setting = $this->db->select('registration')
	                   ->from('sms_setting')
	                   ->get()
	                   ->row();

	                if (!empty($setting) && ($setting->registration==1))
	                { 
	                    #-----------------------------------#
	                    # SMS Gateway Setting
	                    $gateway = $this->db->select('*')
	                       ->from('sms_gateway')
	                       ->where('default_status', 1)
	                       ->get()
	                       ->row();

	                    #-----------------------------------#
	                    # schedules list
	                    $sms_teamplate = $this->db->select('teamplate')
	                        ->from('sms_teamplate')
	                        ->where('status', 1)
	                        ->where('default_status', 1)
							->like('type', 'Registration', 'both')
	                        ->get()
	                        ->row();  
	                        
	                    #-----------------------------------#
	                    # sms  

	                    if(!empty($gateway) && !empty($sms_teamplate)) 
	                    {
	                        $this->load->library('smsgateway');
	                        $template = $this->smsgateway->template([
	                            'patient_name'   => $postData['firstname'].' '.$postData['lastname'],
	                            'patient_id'     => $postData['patient_id'],
	                            'message'        => $sms_teamplate->teamplate
	                        ]); 

	                        $this->smsgateway->send([
	                            'apiProvider' => $gateway->provider_name,
	                            'username'    => $gateway->user,
	                            'password'    => $gateway->password,
	                            'from'        => $gateway->authentication,
	                            'to'          => $postData['mobile'],
	                            'message'     => $template
	                        ]);

	                        // save delivary data
	                        $this->db->insert('custom_sms_info', array(
	                           'gateway' => $gateway->provider_name,
	                           'reciver'          => $postData['mobile'],
	                           'message'          => $template ,
	                           'sms_date_time'    => date("Y-m-d h:i:s")
	                        ));
	                    }
	                }
	                #-------------------------------------------------------#
	            #-------------------------SMS SEND -----------------------------#
	                #-------------------------------------------------------#


					#set success message
					$this->session->set_flashdata('message', display('save_successfully'));
				} else {
					#set exception message
					$this->session->set_flashdata('exception', display('please_try_again'));
				}

				redirect('patient/profile/' . $patient_id);
			} else {
				if ($this->patient_model->update($postData)) {
					#set success message
					$this->db->select('*');
					$this->db->from('patient');
					$query = $this->db->get();
					foreach ($query->result() as $row) {
						$json_customer[] = array('label'=>$row->firstname." ".$row->lastname." - ($row->patient_id)",'value'=>$row->patient_id);
					}
					$cache_file ='./my-assets/js/admin_js/json/customer.json';
					$customerList = json_encode($json_customer);
					file_put_contents($cache_file,$customerList);
					$this->session->set_flashdata('message', display('update_successfully'));
				} else {
					#set exception message
					$this->session->set_flashdata('exception', display('please_try_again'));
				}
				redirect('patient/edit/'.$postData['id']);
			}

		} else {
			$data['content'] = $this->load->view('patient_form',$data,true);
			$this->load->view('layout/main_wrapper',$data);
		} 
	}


	public function profile($patient_id = null, $getid = null)
	{ 
		$data['title'] =  display('patient_information');
		#-------------------------------#
		$this->form_validation->set_rules('patient_id', display('patient_id') ,'required|max_length[11]');
        $this->form_validation->set_rules('critical_status', display('status') ,'required');
        $this->form_validation->set_rules('description', display('description'),'required|trim');
        /*-------------STORE DATA------------*/
		$datetime = $this->input->post('datetime');		

        $data['status'] = (object)$postData = array( 
            'id'              => $this->input->post('id'),
            'cm_patient_id'   => $this->input->post('patient_id'),
			'description'     => $this->input->post('description'),
			'created_by'      => $this->session->userdata("user_id"),
            'critical_status' => $this->input->post('critical_status'),
        );
        if ($this->input->post('id') == null) {
        	$postData['datetime'] = date('Y-m-d H:i:s');
		}  
		$this->load->model('case_manager/status_model');
		if ($this->form_validation->run()) {
			
            /*-----------CREATE A NEW RECORD-----------*/
        	if (($this->input->post('id')==null)) {

                if ($this->status_model->create($postData)) {
                    #set success message
                    $this->session->set_flashdata('message', display('save_successfully'));
                } else {
                    #set exception message
                    $this->session->set_flashdata('exception',display('please_try_again'));
                }
            } else {
                if ($this->status_model->update($postData)) {
                    #set success message
                    $this->session->set_flashdata('message', display('update_successfully'));
                } else {
                    #set exception message
                    $this->session->set_flashdata('exception',display('please_try_again'));
                }
            }

            redirect("patient/profile/$patient_id"); 

        } else {
			if ($getid!=null) {
				$data['status']    = $this->status_model->read_by_id($getid);
			}

			$data['profile'] = $this->patient_model->read_by_id($patient_id);
			$data['documents'] = $this->document_model->read_by_patient($patient_id);
			$data['statuss'] = $this->status_model->read($patient_id);
			$data['content'] = $this->load->view('patient_profile',$data,true);
			$this->load->view('layout/main_wrapper',$data);
		} 
	}

	public function delete_status($id = null) 
    {
		$this->load->model('case_manager/status_model');
        if ($this->status_model->delete($id)) {
            #set success message
            $this->session->set_flashdata('message', display('delete_successfully'));
        } else {
            #set exception message
            $this->session->set_flashdata('exception', display('please_try_again'));
        }
        redirect($_SERVER['HTTP_REFERER']);
    }


	public function edit($patient_id = null) 
	{ 
		$data['title'] = display('patient_edit');
		#-------------------------------#
		$data['patient'] = $this->patient_model->read_by_id($patient_id);
		$data['content'] = $this->load->view('patient_form',$data,true);
		$this->load->view('layout/main_wrapper',$data);
	}
 

	public function delete($patient_id = null) 
	{ 
		if ($this->patient_model->delete($patient_id)) {
			#set success message
			$this->session->set_flashdata('message',display('delete_successfully'));
		} else {
			#set exception message
			$this->session->set_flashdata('exception',display('please_try_again'));
		}
		redirect('patient');
	}



    /*
    |----------------------------------------------
    |        id genaretor
    |----------------------------------------------     
    */
    public function randStrGen($mode = null, $len = null){
        $result = "";
        if($mode == 1):
            $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        elseif($mode == 2):
            $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        elseif($mode == 3):
            $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        elseif($mode == 4):
            $chars = "0123456789";
        endif;

        $charArray = str_split($chars);
        for($i = 0; $i < $len; $i++) {
                $randItem = array_rand($charArray);
                $result .="".$charArray[$randItem];
        }
        return $result;
    }
    /*
    |----------------------------------------------
    |         Ends of id genaretor
    |----------------------------------------------
    */


	public function document()
	{ 
		$data['title'] = display('document_list');
		$data['documents'] = $this->document_model->read();
		$data['content'] = $this->load->view('document',$data,true);
		$this->load->view('layout/main_wrapper',$data);
	} 



    public function document_form()
    {  
        $data['title'] = display('add_document'); 
        /*----------VALIDATION RULES----------*/
        $this->form_validation->set_rules('patient_id', display('patient_id') ,'required|max_length[30]');
        $this->form_validation->set_rules('doctor_name', display('doctor_id'),'max_length[11]');
        $this->form_validation->set_rules('description', display('description'),'trim');
        $this->form_validation->set_rules('hidden_attach_file', display('attach_file'),'required|max_length[255]');
        /*-------------STORE DATA------------*/
        $urole = $this->session->userdata('user_role');
        $data['document'] = (object)$postData = array( 
            'patient_id'  => $this->input->post('patient_id'),
            'doctor_id'   => $this->input->post('doctor_id'),
            'description' => $this->input->post('description'),
            'hidden_attach_file' => $this->input->post('hidden_attach_file'),
            'date'        => date('Y-m-d'),
            'upload_by'   => (($urole==10)?0:$this->session->userdata('user_id'))
        );  

        /*-----------CREATE A NEW RECORD-----------*/
        if ($this->form_validation->run() === true) { 
			$result = $this->patient_model->read_by_patient_id($this->input->post('patient_id'));
			if($result){
				if ($this->document_model->create($postData)) {
					$this->session->set_flashdata('message', display('save_successfully'));
				} else {
					$this->session->set_flashdata('exception',display('please_try_again'));
				}
			}
			else{
				$this->session->set_flashdata('exception',display('patient_id_not_available'));
			}
            redirect('patient/document_form');
        } else {
            $data['doctor_list'] = $this->doctor_model->doctor_list(); 
            $data['content'] = $this->load->view('document_form',$data,true);
            $this->load->view('layout/main_wrapper',$data);
        }  
    } 


    public function do_upload()
    {
        ini_set('memory_limit', '200M');
        ini_set('upload_max_filesize', '200M');  
        ini_set('post_max_size', '200M');  
        ini_set('max_input_time', 3600);  
        ini_set('max_execution_time', 3600);

        if (($_SERVER['REQUEST_METHOD']) == "POST") { 
            $filename = $_FILES['attach_file']['name'];
            $filename = strstr($filename, '.', true);
            $email    = $this->session->userdata('email');
            $filename = strstr($email, '@', true)."_".$filename;
            $filename = strtolower($filename);
            /*-----------------------------*/

            $config['upload_path']   = FCPATH .'./assets/attachments/';
            // $config['allowed_types'] = 'csv|pdf|ai|xls|ppt|pptx|gz|gzip|tar|zip|rar|mp3|wav|bmp|gif|jpg|jpeg|jpe|png|txt|text|log|rtx|rtf|xsl|mpeg|mpg|mov|avi|doc|docx|dot|dotx|xlsx|xl|word|mp4|mpa|flv|webm|7zip|wma|svg';
            $config['allowed_types'] = 'pdf|doc|docx|bmp|gif|jpg|jpeg|jpe|png';
            $config['max_size']      = 0;
            $config['max_width']     = 0;
            $config['max_height']    = 0;
            $config['encrypt_name']  = true; 
            $config['file_ext_tolower'] = true; 
            $config['overwrite']     = false;

            $this->load->library('upload', $config);

            $name = 'attach_file';
            if ( ! $this->upload->do_upload($name) ) {
                $data['exception'] = $this->upload->display_errors();
                $data['status'] = false;
                echo json_encode($data);
            } else {
                $upload =  $this->upload->data();
                $data['message'] = display('upload_successfully');
                $data['filepath'] = './assets/attachments/'.$upload['file_name'];
                $data['status'] = true;
                echo json_encode($data);
            }
        }  
    } 


    public function document_delete($id = null)
    {
    	if ($this->document_model->delete($id)) {

	    	$file = $this->input->get('file');
	    	if (file_exists($file)) {
	    		@unlink($file);
	    	}
    		$this->session->set_flashdata('message', display('save_successfully'));

    	} else {
    		$this->session->set_flashdata('exception', display('please_try_again'));
    	}

    	redirect($_SERVER['HTTP_REFERER']);
	}
	
	// public function patient_list(){
	// 	$data['patient_list'] = $this->patient_model->read();
    //     $patients = [];
    //     foreach ($data['patient_list'] as $value) {
    //         $x['id'] = $value->patient_id;
    //         $x['value'] = "($value->patient_id) - ".$value->firstname." ".$value->lastname;
    //         array_push($patients,$x);
	// 	}
		
	// 	echo json_encode($patients);
	// }



}
